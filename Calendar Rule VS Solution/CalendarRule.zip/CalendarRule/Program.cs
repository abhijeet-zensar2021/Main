﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;

namespace CalendarRule
{
    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = "Url=https://ztdev.crm11.dynamics.com; Username=Harshal@ztd365.onmicrosoft.com; Password=Zensar@1234; AuthType=Office365";
            var crmSvcClient = new CrmServiceClient(connectionString);

            var fetch = @"<fetch mapping='logical'>
                    <entity name='calendarrule' />                                  
                  </fetch>";

            var executeFetchReq = new ExecuteFetchRequest
            {
                FetchXml = fetch
            };

            //Works
            var crmSvcExecuteFetchResponse = crmSvcClient.Execute(executeFetchReq);
           
        }
    }
    
}
