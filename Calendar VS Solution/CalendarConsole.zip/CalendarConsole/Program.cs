﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CalendarConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            string clientId = "c2b575f9-ef65-490b-8741-800f067f2111";
            string clientSecret = "22-OC1YovwX38F~13.K-I1gyusuh4_iUZo";
            string sourceURL = "https://ztdev.crm11.dynamics.com/";
            string targetURL = "https://ztuat.crm11.dynamics.com/";

            //Connect Source environment
            IOrganizationService serviceSource = GetOrganizationServiceClientSecret(clientId, clientSecret, sourceURL);

            if (serviceSource == null)
            {
                Console.WriteLine("Failed to Established Connection on Source environment!!!");
            }

            //Connect Target environment
            IOrganizationService serviceTarget = GetOrganizationServiceClientSecret(clientId, clientSecret, targetURL);
            if (serviceTarget == null)
            {
                Console.WriteLine("Failed to Established Connection on Target environment!!!");
            }

            EntityCollection calendarCollection = RetrieveCalendarRecords(serviceSource);

            if (calendarCollection == null || calendarCollection.Entities.Count == 0)
            {
                Console.WriteLine("No Calendar records found to transfer");
            }

            bool successFlagCalendar = createCalendarRecords(calendarCollection, serviceTarget);

        }

        private static bool createCalendarRecords(EntityCollection calendarCollection, IOrganizationService serviceTarget)
        {
            EntityCollection typeCollTarget = RetrieveCalendarRecords(serviceTarget);

           
            Entity entity = new Entity("calendar");
            string entityName = "calendar";
            foreach (Entity entObj in calendarCollection.Entities)
            {
                //check record is present on target envt
                bool flag = checkRecord(typeCollTarget, new Guid(entObj.Attributes["calendarid"].ToString()), entityName); ;

                entity.Id = new Guid(entObj.Attributes["calendarid"].ToString());
                if (entObj.Attributes.Contains("name"))
                {
                    entity.Attributes["name"] = entObj.Attributes["name"].ToString();
                }

                if (entObj.Attributes.Contains("description"))
                {
                    entity.Attributes["description"] = entObj.Attributes["description"].ToString();
                }
                if (entObj.Attributes.Contains("businessunitid"))
                {
                    EntityReference entref = (EntityReference)entObj.Attributes["businessunitid"];
                    var LookupId = entref.Id;
                    entity.Attributes["businessunitid"] = new EntityReference(entref.LogicalName, LookupId);

                }
                if (entObj.Attributes.Contains("type"))
                {
                    OptionSetValue optionSet = (OptionSetValue)entObj.Attributes["type"];
                    entity.Attributes["type"] = optionSet;
                }

                //if (entObj.Attributes.Contains("hsl_sortorder"))
                //{
                //    entity.Attributes["hsl_sortorder"] = Convert.ToInt32(entObj.Attributes["hsl_sortorder"].ToString());
                //}
                
                if (flag == false)
                {

                    serviceTarget.Create(entity);
                }
                else if (flag == true)
                {
                    serviceTarget.Update(entity);
                }

            }

            return true;
        }

        private static bool checkRecord(EntityCollection typeCollTarget, Guid guidTarget, string entityName)

        {
            foreach (Entity entObj in typeCollTarget.Entities)
            {
                Guid source = Guid.Empty;
                if (entityName == "calendar")
                {
                    source = new Guid(entObj.Attributes["calendarid"].ToString());
                }
               
                if (source == guidTarget)
                {
                    return true;
                }
            }
            return false;
        }

        private static EntityCollection RetrieveCalendarRecords(IOrganizationService serviceSource)
        {
            Console.WriteLine("Fetching Calendar Records....");
            EntityCollection collection = null;

            string fetchXML = @"<fetch top='50' >
                              <entity name='calendar' >
                                <attribute name='holidayschedulecalendarid' />
                                <attribute name='description' />
                                <attribute name='name' />
                                <attribute name='businessunitid' />
                                <attribute name='calendarid' />
                                <attribute name='businessunitidname' />
                                <attribute name='holidayschedulecalendaridname' />
                                <attribute name='type' />
                                <filter>
                                  <condition attribute='createdon' operator='today' />
                                </filter>
                              </entity>
                            </fetch>";
            collection = serviceSource.RetrieveMultiple(new FetchExpression(fetchXML));

            return collection;
        }

        public static IOrganizationService GetOrganizationServiceClientSecret(string clientId, string clientSecret, string organizationUri)
        {
            try
            {
                var conn = new CrmServiceClient($@"AuthType=ClientSecret;url={organizationUri};ClientId={clientId};ClientSecret={clientSecret}");
                Console.WriteLine("Connected to environment -" + organizationUri);
                return conn.OrganizationWebProxyClient != null ? conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;
            }
            catch (Exception ex)
            {

                Console.WriteLine("Error while connecting to CRM " + ex.Message);
                Console.ReadKey();
                return null;
            }
        }
    }
}
